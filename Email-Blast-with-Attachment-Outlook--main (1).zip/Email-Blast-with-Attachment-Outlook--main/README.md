#REQUIREMENTS

#1. Word docx containing the contents of the email blast (e.g. xxx.docx)

#2. Excel Spreadsheet containing all the intended receipients (e.g. xxx.xlsx)

#3. Attachment pdf file (e.g. xxx.pdf)

#4. All the required modules as stated in the import area

#5. Outlook app must be open!!!

#6. Remember to rename the items with "***""

#7. Make sure this python script, the word doc, the pdf file, the excel sheet are in the same folder in your local

#8. For spacing between each line, please "ENTER" 2 times instead of once to show 1 line of spacing
